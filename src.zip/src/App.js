import React, { useState } from 'react';
import './App.css';

//https://api.github.com/search/repositories?q=html
function App() {
  const [inputValue,setInputValue] = React.useState("");
  const [repos,setRepos] = React.useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(20);

  React.useEffect(() => {
    if(!inputValue)
    {
      return;
    }
    
    // make API calls
    fetch('https://api.github.com/search/repositories?q='+inputValue+'&sort=forks&order=desc')
      .then(response => response.json())
      .then(data => {
        console.log(data);
        setRepos(data.items);
      });
  },[inputValue])

  const indexOfLastPost = currentPage*postsPerPage;
  const indexOfFirstPost = indexOfLastPost-postsPerPage;
  const currentPosts = repos.slice(indexOfFirstPost,indexOfLastPost);
  let totalPages = parseInt(repos.length/postsPerPage);
  let index=0,ind=0;
  if(repos.length%postsPerPage!=0)
  {
    totalPages+=1;
  }
  console.log(totalPages);
  
  
  return (
    <div>
      <div className="searchBar">
      <form onSubmit={evt => {
        evt.preventDefault();
        setInputValue(evt.target.elements.query.value);
      }}>
        <input name='query' className='github_search_input' placeholder='Search Repositories...' list="suggestions"></input>
        <datalist id="suggestions">
            <option value="Java"></option>
            <option value="Javascript"></option>
            <option value="Python"></option>
        </datalist>
        
      
      <input type="Submit" value="Search" className="searchButton"></input>
      </form>
    </div>
    <br></br>
    <br></br>
    <div>
    {currentPosts.map(repo => {
        ind+=1;
        if(ind>1)
        {
          return;
        }
        return <div className="info">
        {repos.length} results found...
        </div>
      })}
      
    </div>
    <br></br>
    <div className="repoContent">
      
      {currentPosts.map(repo => {
        
        return <div className="repo_detail">
          <div className="owner_avatar">
            
            <img src={repo.owner.avatar_url} alt="Owner's Avatar" ></img>
          </div>
          <div className="repo_desc">
            Repository Name - {repo.name}<br></br>
            Owner - {repo.owner.login}<br></br>
            Fork Count - {repo.forks_count}<br></br>
            Stars Count - {repo.stargazers_count}<br></br>
          </div>
        </div>
      })}
      </div>
      
      
      <div>
      {currentPosts.map(repo => {
        index+=1;
        if(index>1)
        {
          return;
        }
        return <div className="pagination">
        <button onClick={()=>{
          if(currentPage!=1)
          {
            setCurrentPage(currentPage-1);
          }
        }}>Prev Page</button>
        Page {currentPage}
        <button onClick={()=>{
          if(currentPage!=totalPages)
          setCurrentPage(currentPage+1);
        }}>Next Page</button>
        </div>
      })}
        
      </div>
      
      
    </div>
  );
}

export default App;
